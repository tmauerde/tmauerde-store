# TMAUERDE — GitHub Pages Final

Static HTML/CSS/JS. No npm, build process, or external image URLs.

## Upload
Upload the contents of this ZIP directly to the root of `tmauerde-store`:
- index.html
- styles.css
- script.js
- assets/

Then: Settings → Pages → Deploy from a branch → main → /(root) → Save.

Product names and prices are demo catalog values until replaced with the final catalog.
