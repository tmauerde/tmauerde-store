# TMAUERDE FINAL 3x2
GitHub Pages-ready static store. No npm/build.

Upload everything inside this ZIP directly to the repository root.
GitHub: Settings → Pages → Deploy from a branch → main → /(root) → Save.

This version intentionally uses a 3-column x 2-row featured product layout on desktop.
Product prices/review counts are demo catalog values.
