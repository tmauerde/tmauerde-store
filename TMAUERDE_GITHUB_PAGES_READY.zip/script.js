const categories=['BACKPACKS','BAGS','WALLETS','CAPS','EYEWEAR','WATCHES'];
const products=[
['T1 Signature Backpack','Backpack','$129.99'],
['T2 Essential Bag','Essential Bag','$99.99'],
['T3 Classic Wallet','Classic Wallet','$49.99'],
['T4 Signature Cap','Signature Cap','$34.99'],
['T5 Modern Eyewear','Modern Eyewear','$89.99'],
['T6 Essential Watch','Essential Watch','$149.99']
];
document.querySelector('#categoryGrid').innerHTML=categories.map((x,i)=>`<article class="card category"><div class="visual" data-mark="${String(i+1).padStart(2,'0')}"></div><h3>${x} →</h3></article>`).join('');
document.querySelector('#productGrid').innerHTML=products.map((p,i)=>`<article class="card product"><div class="visual" data-mark="T${i+1}"></div><div class="info"><h3>${p[0]}</h3><p>${p[1]}</p><span class="price">${p[2]}</span></div><button class="add">ADD TO BAG +</button></article>`).join('');
let count=0; document.querySelectorAll('.add').forEach(b=>b.onclick=()=>{document.querySelector('#count').textContent=++count;let t=document.querySelector('#toast');t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1100)});
