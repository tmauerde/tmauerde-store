# TMAUERDE STORE
Static GitHub Pages website. No npm or build step.

Upload `index.html`, `styles.css`, `script.js` and the `assets` folder directly to the repository root.

GitHub Pages: Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.

Product names and prices are demo catalog values until replaced with the final commercial catalog.
